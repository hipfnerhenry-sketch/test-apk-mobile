plugins { id("com.android.application") }

android {
    namespace = "com.henry.mysterybutton"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.henry.mysterybutton"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
