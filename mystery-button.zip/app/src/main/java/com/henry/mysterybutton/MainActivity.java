package com.henry.mysterybutton;

import android.app.Activity;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private MediaPlayer player;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(12, 12, 12));

        Button button = new Button(this);
        button.setText("PRESS");
        button.setTextSize(34);
        button.setAllCaps(true);
        button.setOnClickListener(v -> {
            if (player != null) {
                player.release();
                player = null;
            }
            player = MediaPlayer.create(this, R.raw.mystery);
            if (player != null) {
                player.setOnCompletionListener(mp -> {
                    mp.release();
                    if (player == mp) player = null;
                });
                player.start();
            }
        });

        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 420, Gravity.CENTER);
        p.setMargins(40, 40, 40, 40);
        root.addView(button, p);
        setContentView(root);
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
