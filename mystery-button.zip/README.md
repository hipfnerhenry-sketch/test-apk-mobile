# The Button

A minimal one-button Android app for testing a phone-only APK build/install pipeline.

## Build
GitHub Actions builds the APK automatically after a push to `main`.

## Install
Open the successful **Build APK** workflow run, download the `mystery-apk` artifact,
extract it, and open `app-debug.apk` on Android.

The audio asset is retrieved automatically during the cloud build.
